package com.example.scientific_calculator;

public class JsCallback {
}
