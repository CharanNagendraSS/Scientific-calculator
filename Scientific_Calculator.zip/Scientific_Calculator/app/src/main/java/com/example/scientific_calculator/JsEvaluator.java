package com.example.scientific_calculator;

public class JsEvaluator {
    public JsEvaluator(MainActivity mainActivity) {
    }

    public void evaluate(String toString, JsCallback jsCallback) {
    }
}
