package com.example.scientific_calculator;


import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    JsEvaluator jsEvaluator;
    EditText Text;
    boolean shift = false;
    Button shiftbutton, bequal,brad,bcos,btan,bsin,bcsc,bsec,bcot,blog,bsqrt,bxy,bceil;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        Text=(EditText)findViewById(R.id.displayText);
        shiftbutton = (Button)findViewById(R.id.shiftButton);
        blog=findViewById(R.id.blog);
        bequal=findViewById(R.id.bequal);
        bceil=findViewById(R.id.bceil);
        bcos=findViewById(R.id.bcos);
        bsin=findViewById(R.id.bsin);
        btan=findViewById(R.id.btan);
        bxy=findViewById(R.id.bxy);

        bcsc=findViewById(R.id.bcsc);
        bsec=findViewById(R.id.bsec);
        bcot=findViewById(R.id.bcot);
        bsqrt=findViewById(R.id.bsqrt);
        brad=findViewById(R.id.brad);
        jsEvaluator = new JsEvaluator(this);
        Text.setText("0");





        bequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    String val = Text.getText().toString();
                    String replacedstr = val.replace('÷','/').replace('×','*');
                    double result = eval(replacedstr);
                    Text.setText(String.valueOf(result));
                    Toast.makeText(getApplicationContext(),"Result Calculated",Toast.LENGTH_LONG).show();
                    //String text=Text.getText().toString();
                    //Intent i=new Intent(MainActivity.this,history.class);
                    //startActivity(i);
                    //Text.setText(val);

                }
                catch (Exception e)
                {
                    Text.setText("Syntax error");
                }

            }
        });

        brad.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.toRadians(x);
                Text.setText(String.valueOf(result));
            }
        });

        blog.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.log(x);
                Text.setText(String.valueOf(result));
            }
        });

        bsqrt.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.sqrt(x);
                Text.setText(String.valueOf(result));
            }
        });
        bxy.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {

                double x=Double.parseDouble(String.valueOf(Text.getText().charAt(0)));
                double x1=Double.parseDouble(String.valueOf(Text.getText().charAt(1)));
                double result = Math.pow(x,x1);
                Text.setText(String.valueOf(result));
            }
        });
        bcos.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.cos(Math.toRadians(x));
                Text.setText(String.valueOf(result));
                Toast.makeText(getApplicationContext(),"Result Calculated",Toast.LENGTH_LONG).show();

            }
        });
        bsin.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.sin(Math.toRadians(x));
                Text.setText(String.valueOf(result));
            }
        });
        btan.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.tan(Math.toRadians(x));
                Text.setText(String.valueOf(result));
            }
        });
        bcsc.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.asin(Math.toRadians(x));
                Text.setText(String.valueOf(result));
            }
        });
        bsec.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.acos(Math.toRadians(x));
                Text.setText(String.valueOf(result));
            }
        });
        bcot.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.atan(Math.toRadians(x));
                Text.setText(String.valueOf(result));
            }
        });
        bceil.setOnClickListener(new View.OnClickListener() {
            @java.lang.Override
            public void onClick(View view) {
                double x=Double.parseDouble(Text.getText().toString());
                double result = Math.ceil(x);
                Text.setText(String.valueOf(result));
            }
        });

    }

    public void One(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("1");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"1");
            Text.setSelection(Text.getText().length());}

    }
    public void Two(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("2");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"2");
            Text.setSelection(Text.getText().length());}
    }
    public void Three(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("3");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"3");
            Text.setSelection(Text.getText().length());}
    }
    public void Four(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("4");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"4");
            Text.setSelection(Text.getText().length());}
    }
    public void Five(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("5");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"5");
            Text.setSelection(Text.getText().length());}
    }
    public void Six(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("6");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"6");
            Text.setSelection(Text.getText().length());}
    }
    public void Seven(View view){

        if(Text.getText().toString().equals("0")){
            Text.setText("7");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"7");
            Text.setSelection(Text.getText().length());}
    }
    public void Eight(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("8");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"8");
            Text.setSelection(Text.getText().length());}
    }
    public void Nine(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("9");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"9");
            Text.setSelection(Text.getText().length());}
    }
    public void Zero(View view){
        Text.setText(Text.getText()+"0");
        Text.setSelection(Text.getText().length());
    }
    public void Zeros(View view){
        Text.setText(Text.getText()+"00");
        Text.setSelection(Text.getText().length());
    }
    public void ceil(View view){
        Text.setText(Text.getText());
        Text.setSelection(Text.getText().length());
    }
    public void Plus(View view){
        Text.setText(Text.getText()+"+");
        Text.setSelection(Text.getText().length());
    }
    public void Minus(View view){
        Text.setText(Text.getText()+"-");
        Text.setSelection(Text.getText().length());
    }
    public void Multiply(View view){
        Text.setText(Text.getText()+"*");
        Text.setSelection(Text.getText().length());
    }
    public void Divide(View view){
        Text.setText(Text.getText()+"/");
        Text.setSelection(Text.getText().length());
    }
    public void mod(View view){
        Text.setText(Text.getText()+"%");
        Text.setSelection(Text.getText().length());
    }
    public void Dot(View view){
        Text.setText(Text.getText()+".");
        Text.setSelection(Text.getText().length());
    }
    public void Exp(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("Math.exp(");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"Math.exp(");
            Text.setSelection(Text.getText().length());}

    }
    public void Ans(View view){
        Text.setText(Text.getText());
        Text.setSelection(Text.getText().length());
    }
    public void Cos(View view){
        double x=Double.parseDouble(Text.getText().toString());
       double result = Math.cos(Math.toRadians(x));
        Text.setText(String.valueOf(result));
        if(Text.getText().toString().equals("0")){
            Text.setText("Math.cos(");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"Math.cos(");
            Text.setSelection(Text.getText().length());}

    }


    public void Shift(View view)
    {

        if(shift == false)
        {
            shift = true;

            shiftbutton.setBackgroundColor(Color.parseColor("#ff8383"));
            bsin.setText("SIN");
            bsin.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.sin(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                }
            });
            bcos.setText("COS");
            bcos.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.cos(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                }
            });
            btan.setText("TAN");
            btan.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.tan(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                }
           });
            bceil.setText("ceil");
            bceil.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.ceil(x);
                    Text.setText(String.valueOf(result));
                }
            });
            bsqrt.setText("√");
            bsqrt.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.sqrt(x);
                    Text.setText(String.valueOf(result));
                }
            });
            brad.setText("Rad");
            brad.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.toRadians(x);
                    Text.setText(String.valueOf(result));
                }
            });



        }
        else if(shift==true)
        {
            shift=false;
            shiftbutton.setBackgroundColor(Color.TRANSPARENT);
            bsin.setText("asin");
            bsin.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.asin(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                        }
                    });
            bcos.setText("acos");
            bcos.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.acos(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                }
            });
            btan.setText("atan");
            btan.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.atan(Math.toRadians(x));
                    Text.setText(String.valueOf(result));
                }
            });
            bceil.setText("floor");
            bceil.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.floor(x);
                    Text.setText(String.valueOf(result));
                }
            });
            bsqrt.setText("3 √");
            bsqrt.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.cbrt(x);
                    Text.setText(String.valueOf(result));
                }
            });
            brad.setText("Deg");
            brad.setOnClickListener(new View.OnClickListener() {
                @java.lang.Override
                public void onClick(View view) {
                    double x=Double.parseDouble(Text.getText().toString());
                    double result = Math.toDegrees(x);
                    Text.setText(String.valueOf(result));
                }
            });


        }
    }

    public void RightBracket(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText(")");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+")");
            Text.setSelection(Text.getText().length());}
    }
    public void LeftBracket(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("(");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"(");
            Text.setSelection(Text.getText().length());}
    }
    public void Ac(View view){
        Text.setText("0");
        Text.setSelection(Text.getText().length());
    }
    public void Del(View view){
        String text = Text.getText().toString();
        if(text.length()==1){
            Text.setText("0");
        }else{
            Text.setText(text.substring(0, text.length() - 1));
            Text.setSelection(Text.getText().length());
        }

    }
    public void C(View view){
        String text = Text.getText().toString();
        if(text.length()==1){
            Text.setText("0");
        }else{
            Text.setText(text.substring(0, text.length() - 1));
            Text.setSelection(Text.getText().length());
        }
    }
    public void X2(View view){
        Text.setText(Text.getText()+"*2");
        Text.setSelection(Text.getText().length());
    }
    public void Power(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("Math.pow(");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"Math.pow(");
            Text.setSelection(Text.getText().length());}
    }
    public void Sqrt(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText("Math.sqrt(");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+"Math.sqrt(");
            Text.setSelection(Text.getText().length());}
    }
    public void Comma(View view){
        if(Text.getText().toString().equals("0")){
            Text.setText(",");
            Text.setSelection(Text.getText().length());
        }else{Text.setText(Text.getText()+",");
            Text.setSelection(Text.getText().length());}
    }

    public void Fac(View view){
        int i,fact=1;
        int number=Integer.parseInt(Text.getText().toString());//It is the number to calculate factorial
        for(i=1;i<=number;i++){
            fact=fact*i;
        }
        Text.setText(""+fact);
        Text.setSelection(Text.getText().length());
    }

    public void Pi(View view){
        double x=Double.parseDouble(Text.getText().toString());
        double result = x*3.142;
        Text.setText(String.valueOf(result));
        //Text.setText(Text.getText()*"3.14159");
          }
    public void Rad(View view){
        //double Ans =Double.parseDouble(Text.getText().toString())*0.01745329252;
        //Text.setText(""+Ans);
        Text.setSelection(Text.getText().length());
    }
    public void Reci(View view){
        double Ans =1/Double.parseDouble(Text.getText().toString());
        Text.setText(""+Ans);
        Text.setSelection(Text.getText().length());
    }
    public void X3(View view){
        double Ans =Double.parseDouble(Text.getText().toString());
        Ans=Ans*Ans*Ans;
        Text.setText(""+Ans);
        Text.setSelection(Text.getText().length());
        Toast.makeText(getApplicationContext(),"Result Calculated",Toast.LENGTH_LONG).show();

    }


    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected: " + (char)ch);
                return x;
            }


            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if      (eat('+')) x += parseTerm(); // addition
                    else if (eat('-')) x -= parseTerm(); // subtraction
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if      (eat('*')) x *= parseFactor(); // multiplication
                    else if (eat('/')) x /= parseFactor(); // division
                    else if (eat('%')) x %= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor(); // unary plus
                if (eat('-')) return -parseFactor(); // unary minus

                double x;
                int startPos = this.pos;
                if (eat('(')) { // parentheses
                    x = parseExpression();
                    eat(')');
                } else if ((ch >= '0' && ch <= '9') || ch == '.') { // numbers
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') { // functions
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x = Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x = Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x = Math.tan(Math.toRadians(x));
                    else if (func.equals("log")) x = Math.log10(x);
                    else if (func.equals("ln")) x = Math.log(x);
                    else throw new RuntimeException("Unknown function: " + func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char)ch);
                }

                if (eat('^')) x = Math.pow(x, parseFactor()); // exponentiation

                return x;
            }
        }.parse();
    }
}
